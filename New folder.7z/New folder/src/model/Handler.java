//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package model;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.HashSet;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JPanel;

import frontEnd.ProjectGUI;

/**
 * Class to load projects.  
 * 
 * called by GUI, loads project buttons.
 * 
 * @author Benjamin
 * 
 * @version Alpha 0.0.08
 */
public class Handler extends AbstractHandler {
	/* panel attachments may require a call to super(not sure), as the abstract extends JScrollPane.
	 * e.g.: super().addActionListener()
	 * Abstract parent should be filled out first!!!
	 */
	private static final long serialVersionUID = 1933113322812413087L;
	
	//Default project panel implementation.
	public Handler() throws IOException {
		super();
	}
	
	public void setUp() {
		//super.setUp();
	}

	//Calls ProjectIO getProjects().
	@Override
	public void loadButtons() {
		super.loadButtons();
	}

	@Override
	public boolean deleteProject(String theProject) {

		// TODO Auto-generated method stub
		return super.deleteProject(theProject);
	}

	@Override
	public boolean addProject(String theProject) {
		return super.addProject(theProject);
	}

	@Override
	public boolean deleteItem(String theItem) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
//	public Map<?, ?> getMap(String theProject) {
//		// TODO Auto-generated method stub
//		return null;
//	}
}
