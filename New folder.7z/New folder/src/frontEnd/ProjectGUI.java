//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package frontEnd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

import model.Handler;
import model.ProjectHandler;

/**
 * Project item GUI class. 
 * 
 * @author Daniel Stocksett
 * 
 * @version Alpha 0.0.05
 */
public class ProjectGUI extends AbstractGUI {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2796607903023915076L;
	/*
	 * Things needed to build GUI...
	 */
	//private JPanel myLeftPanel;
	private JScrollPane myCenterPanel;
	private JPanel myRightPanel;
	
	/*
	 * Add override panels to build functionality--just mirroring its parent class now.
	 */
	public ProjectGUI(String theProject) {
		super();
		setTitle("Project: " + theProject);
		// myLeftPanel = new JPanel();
		 myCenterPanel = new ProjectHandler(theProject);
		 myRightPanel= new JPanel();
		 //myRightPanel = new Window(); //uncomment and replace after window coded.
	}

	@Override
	public void createToolBar() {
		super.createToolBar();
	}

	@Override
	public void start() {
		super.start();
		
		setLayout(new BorderLayout());
		
		myRightPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH/2, DEFAULT_HEIGHT));
		myRightPanel.setBackground(Color.WHITE);
		myRightPanel.setVisible(true);
		
		add(myRightPanel, BorderLayout.EAST);
		
		//temp test code next 2 lines
		myCenterPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH/2, DEFAULT_HEIGHT));
		myCenterPanel.setBackground(Color.RED);
		
		//end test code
		myCenterPanel.getViewport().setOpaque(false);
		myCenterPanel.setVisible(true);
		
		add(myCenterPanel, BorderLayout.CENTER);
		
		pack();
	}



}
