//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package frontEnd;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * @author Daniel Stocksett
 * 
 * @version Alpha 0.0.03
 * 
 * SIMPLE io class for settings.
 */
public class SettingsIO {
	public String SETTINGS = "Settings";
	public File myFile;
	public JFileChooser myCh;

	/**
	 * Constructor.
	 */
	public SettingsIO() {
		myCh = new JFileChooser();
		myFile = new File("settings.txt");
		myCh.setFileFilter(new FileNameExtensionFilter("Text File", "txt"));
	}

	/**
	 * Method for import and replacement - needs replacement hashing.
	 * 
	 * @throws IOException
	 */
	public void inport() throws IOException {
		File file = getLocation("Choose file to inport");
		
		if (file != null) {
			Path  temp = file.toPath();
		try {

			if (myFile.renameTo(new File("./settings.bac" ))) {
				myFile.delete();
			}
			Files.copy(temp, myFile.toPath());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}
	/**
	 * Method for export. -no replacement.
	 * 
	 * @throws IOException
	 */
	public void export() throws IOException {

		File file = getLocation("Choose file to inport");
		
		if (file != null) {
			Path  temp = file.toPath();
		try {

			Files.copy(myFile.toPath(), temp);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}

	}
	/**
	 * JFileChooser method.
	 * 
	 * @param theStr label for myCh.
	 * @return returns a file.
	 * @throws IOException
	 */
	public File getLocation(final String theStr) throws IOException {
		File tempFile = null;
		int temp = myCh.showOpenDialog(null);
		if (temp == JFileChooser.APPROVE_OPTION) {
			tempFile = myCh.getSelectedFile();
		} else {
			JOptionPane.showMessageDialog(null, "No file Chosen?!?!?");
		}
		return tempFile;

	}
	/**
	 * reserved for file replacment function.
	 */
	public void writeFile() {


	}

}
