/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package frontEnd;

public interface InterfaceGUI {
       public void start();
       public void createToolBar();
       
}
