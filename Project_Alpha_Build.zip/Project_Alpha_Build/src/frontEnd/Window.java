//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package frontEnd;

import java.awt.Dimension;

import javax.swing.JPanel;

/**
 * Sizable scalable display window. 
 * 
 * @author Fill in your name!
 * 
 * @version Alpha 0.0.05
 */
public class Window extends JPanel {
	/*
	 * Needs setup for generic display.
	 */
	public Window(Object theDoc, Dimension theSize, Dimension theScale) {
		
	}
	
	private void setUp() {
		//Put new Listener here where "null" is. --anonymous inner class.
		addMouseListener(null);
	}

}
