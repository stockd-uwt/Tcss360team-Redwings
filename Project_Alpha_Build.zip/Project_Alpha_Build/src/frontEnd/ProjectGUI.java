//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package frontEnd;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 * Project item GUI class. 
 * 
 * @author Fill in your name!
 * 
 * @version Alpha 0.0.05
 */
public class ProjectGUI extends AbstractGUI {
	/*
	 * Things needed to build GUI...
	 */
	private JPanel myLeftPanel;
	private JScrollPane myCenterPanel;
	private JPanel myRightPanel;
	
	/*
	 * Add override panels to build functionality--just mirroring its parent class now.
	 */
	public ProjectGUI(String theProject) {
		super();
	}

	@Override
	public void createToolBar() {
		// TODO Auto-generated method stub
		super.createToolBar();
	}

	@Override
	public void start() {
		// TODO Auto-generated method stub
		super.start();
	}



}
