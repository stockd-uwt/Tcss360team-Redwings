//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
/*
 * Parts of this program were used for assignment 05 for CSS 305 winter 2019.
 * It is now used for the project of CS 360 
 * This file is owned by Benjamin De Jager
 */

package frontEnd;

import java.awt.EventQueue;

/**
 * This runs and controls all the things needed for the program to run.
 * @author benjad2
 * @version 0.0.1
 */
public final class Driver {

    /**
     * private constructor to prevent external instantiation.
     * @return 
     */
    private void projectMain() {
        throw new IllegalStateException();
    }
    
    /**
     * This gets the program started. it has no special functionality beyond that.
     * @param theArgs these are not used.
     * pre: none.
     * post: a instance of the GUI class is created, started and thus displayed to the user.
     */
    public static void main(final String[] theArgs) { //Edit: DS 11/22/19
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
            	GUI inst = new GUI(); //needed private instantiation -DS.
                 inst.start();
            }
        });
    }


}

