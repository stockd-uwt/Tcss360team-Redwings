package tests;

import static org.junit.Assert.*;
import frontend.InfoTab;

import org.junit.Before;
import org.junit.Test;

/**
 * 
 * Tests the GUI
 *
 */
public class JUnitTests {
    
    /** A Circle to use in the tests. */
    private InfoTab myTab;
    
    /**
     * A method to initialize the test fixture before each test.
     */
    @Before
    public void setUp() { 
        myTab = new InfoTab();
    }
    
    /**
     * Test of the default constructor.
     */
    @Test
    public void testPassableVersionNum() {

    	assertEquals(myTab.getVersion(), "0.0.01");
        
    }
}














