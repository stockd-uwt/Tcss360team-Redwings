//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package frontEnd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import model.Handler;

/**
 * Main GUI class. 
 * 
 * @author Daniel Stocksett
 * 
 * @version Alpha 0.0.05
 */
public class GUI extends AbstractGUI implements WindowListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6165237794493038207L;
	/*
	 * Things needed to build GUI...
	 */
	//private JPanel myLeftPanel;
	private Handler myCenterPanel;
	private JPanel myRightPanel;

	/*
	 * Add override panels to build functionality--just mirroring its parent class now.
	 */
	public GUI() throws IOException {
		 super();
		// myLeftPanel = new JPanel();
		 myCenterPanel = new Handler();
		 myRightPanel= new JPanel();
		 //myRightPanel = new Window(); //uncomment and replace after window coded.
	 }

 @Override
	public void createToolBar() {
		super.createToolBar();
	}

	@Override
	public void start() {
		super.start();
		this.setTitle(TITLE);

		addWindowListener(this);
		
		setLayout(new BorderLayout());
		myRightPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH/2, DEFAULT_HEIGHT/3));
		myRightPanel.setBackground(Color.WHITE);
		
		myRightPanel.setVisible(true);
		add(myRightPanel, BorderLayout.EAST);
		//temp test code next 2 lines
		//myCenterPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH/2, DEFAULT_HEIGHT));
		//myCenterPanel.setBackground(Color.BLUE);
		//end test code
		//myCenterPanel.getViewport().setOpaque(false);
		myCenterPanel.setVisible(true);
		myCenterPanel.addPropertyChangeListener(new GUIListener());
		add(myCenterPanel, BorderLayout.CENTER);
		//((Handler) myCenterPanel).setup();
		pack();
		
	}

	@Override
	public void windowOpened(WindowEvent e) {}
	
	@Override
	public void windowClosing(WindowEvent e) {
		myCenterPanel.save();
	}
	
	@Override
	public void windowClosed(WindowEvent e) {}
	
	@Override
	public void windowIconified(WindowEvent e) {}
	
	@Override
	public void windowDeiconified(WindowEvent e) {}
	
	@Override
	public void windowActivated(WindowEvent e) {}
	
	@Override
	public void windowDeactivated(WindowEvent e) {}
	
	private final class GUIListener implements PropertyChangeListener  {
		
		@Override
		public void propertyChange(PropertyChangeEvent evt) {
			
	
		if (evt.getPropertyName().equals(myCenterPanel.toString()))	{
			ProjectGUI tmp = new ProjectGUI(evt.getPropertyName());
			tmp.start();
		}
		}
		
	}

}
