/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package frontEnd;

/**
 * @author Daniel Scottset.
 * @version 1.0.04
 */
public interface InterfaceGUI {
       public void start();
       public void createToolBar();
       
}
