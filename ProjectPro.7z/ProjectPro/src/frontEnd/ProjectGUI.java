//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package frontEnd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

import model.Handler;
import model.ProjectHandler;

/**
 * Project item GUI class. 
 * 
 * @author Daniel Stocksett
 * 
 * @version 1.0.04
 */
public class ProjectGUI extends AbstractGUI {
	/**
	 * Serial id.
	 */
	private static final long serialVersionUID = -2796607903023915076L;
	/*
	 * Things needed to build GUI...
	 */
	private ProjectHandler myCenterPanel;
	private JPanel myRightPanel;
	
	/**
	 * constructor.
	 */
	public ProjectGUI(String theProject) throws IOException {
		super();
		setTitle("Project: " + theProject);
		// myLeftPanel = new JPanel();
		 myCenterPanel = new ProjectHandler(theProject);
		 myRightPanel= new JPanel();
		 //myRightPanel = new Window(); //uncomment and replace after window coded.
	}

	/**
	 * Just calls super.
	 */
	@Override
	public void createToolBar() {
		super.createToolBar();
	}

    /**
     * Sets title, builds the frame.
     */
	@Override
	public void start() {
		super.start();
		
		setLayout(new BorderLayout());
		
		myRightPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH/2, DEFAULT_HEIGHT));
		myRightPanel.setBackground(Color.WHITE);
		myRightPanel.setVisible(true);
		
		add(myRightPanel, BorderLayout.EAST);
		myCenterPanel.getViewport().setOpaque(false);
		myCenterPanel.setVisible(true);
		myCenterPanel.addPropertyChangeListener(new GUIListener());
		add(myCenterPanel, BorderLayout.CENTER);
		
		pack();
	}
	/**
	 * Populates the view window.
	 */
	private void setPane() {
		 JPanel dummy = new JPanel();
		 dummy.setPreferredSize(new Dimension(DEFAULT_WIDTH/2, DEFAULT_HEIGHT));
		 dummy.setBackground(Color.WHITE);
		 dummy.add(myRightPanel);
		 add(dummy, BorderLayout.EAST);
		 pack();

	}
	/**
	 * Listener class for property change.
	 * 
	 * @author Daniel Stocksett
	 *
	 */
	private final class GUIListener implements PropertyChangeListener  {

		@Override
		public void propertyChange(PropertyChangeEvent evt) {
			Window win;
		


		if (evt.getPropertyName().equals(myCenterPanel.toString()))	{
			try {
				 win = new Window(evt.getPropertyName(), new Dimension(DEFAULT_WIDTH/2, DEFAULT_HEIGHT));
				
				 myRightPanel = win;
				 setPane();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		}
		
	}
}
