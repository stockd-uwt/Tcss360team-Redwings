//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package frontEnd;

/**
 * Class for settings, may wish to move menu bar here... 
 * 
 * @author Fill in your name!
 * 
 * @version 0.0.0
 * unimplemented class present for possable future user stories.
 */
public class Settings {

}
