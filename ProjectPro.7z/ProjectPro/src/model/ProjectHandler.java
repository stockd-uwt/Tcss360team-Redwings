//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package model;

import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

import javax.swing.JPanel;

/**
 * Class to load and provide project items. 
 * 
 * called by ProjectGUI, loads project item buttons.
 * 
 * @author Benjamin
 * 
 * @version Alpha 0.0.08
 */
public class ProjectHandler extends AbstractHandler {
	/* panel attachments may require a call to super(not sure), as the abstract extends JScrollPane.
	 * e.g.: super().addActionListener()
	 * Abstract parent should be filled out first!!!
	 */
	private static final long serialVersionUID = 3498482854205170500L;
	
	/*
	 * This is the map of maps which is used to pass to mainGUI the users's project's
	 * and their items.
	 * becomes "null"
	 */
	private static String theName;
	private static Map<String, ?> myProjects;

	//needs to load the items for a given project as buttons.
	public ProjectHandler(String theProject) throws IOException {
		super(theProject);
		theName = theProject;
		//I can't cast this properly for some reason
	}
	
	//eclipse was complaining about this not being implemented even though its parent does.
	@Override
	public void setUp() {
		//super.setUp();
	}

	//we do allow projectgui to delete items however.
	@Override
	public boolean deleteItem(String theItem) {
		return super.deleteItem(theItem, theName);
	}

	//we don't want projectgui to delete projects.
	@Override
	public boolean deleteProject(String theProject) {
		return false;
	}
}
