//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package model;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.IOException;

/**
 * Class to handle project and project item IO. 
 * 
 * @author David Melanson
 * 
 * @version Alpha 0.0.09
 */
public class ProjectIO {
	
	/**
	 * Projects which point to Items which have a filepath
	 */
	public HashMap<String, Map<String, String>> myProjectMap;
	
	public ProjectIO() {
		//myData = new LinkedList<Node>();
		myProjectMap = new HashMap<String, Map<String, String>>();
	}
	/**
	 * loads files from projects.txt and items.txt into the map
	 * @throws IOException
	 */
	public void load() throws IOException {
		BufferedReader projects = new BufferedReader(new FileReader("./projects.txt")); 
		BufferedReader items = new BufferedReader(new FileReader("./items.txt")); 

		String project;
		while ((project = projects.readLine()) != null) {
			myProjectMap.put(project, new TreeMap<String, String>());
			String item;
			while ((item = items.readLine()) != null && !(item.equals("///***///"))) {
				myProjectMap.get(project).put(item, items.readLine()); // next item is path
				//System.out.println(item);
			}
		}
		
		projects.close();
		items.close();
	}
	
//	//load items belonging to projects to their project map.
//	private void loadProjectItems() {
//		
//	}
	//returns the keySet or list of projects (implementation dependent
	//- Change return type to list for node implementation)
	public Set<String> getProjects() {
		return myProjectMap.keySet();
	}
	
	/**
	 * @param theProject
	 * @return returns copy of item -> filepath map
	 */
	public Map<String,String> getMap(String theProject) {
		TreeMap<String, String> tree = new TreeMap<>();
		//System.out.println("theProject_getMap:"+theProject);
		for (String key : myProjectMap.get(theProject).keySet()) {
			tree.put(key, myProjectMap.get(theProject).get(key));
		}
		
		return tree;
		
	}
	
	/**
	 * sets new item.
	 */
	public boolean setNewItem(String project, String theItem, String theLocation) {
		myProjectMap.get(project).put(theItem, theLocation);
		return true;
	}
	/**
	 * 
	 * sets new project
	 */
	public void setNewProject(String theProject) {
		myProjectMap.put(theProject, new TreeMap<String, String>());
	}
	/**
	 * deletes item. 
	 */
	public boolean deleteItem(String theProject, String theItem) {
		myProjectMap.get(theProject).remove(theItem);
		return true;
	}
	/**
	 * 
	 * deletes project
	 */
	public void deleteProject(String theProject) {
		myProjectMap.remove(theProject);
	}
	
	/**
	 * method writes out projects and their corresponding items to projects.txt and items.txt
	 * 
	 * @return true if file sava data was succesful
	 */
	public boolean saveData() {
		PrintWriter writerProject = null;
		PrintWriter writerItems = null;
		try {
			writerProject = new PrintWriter("./projects.txt");
			writerItems = new PrintWriter("./items.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		
		for (String project : myProjectMap.keySet()) {
			writerProject.write(project);
			writerProject.write("\n");
			for (String fileName : myProjectMap.get(project).keySet()) {
				writerItems.write(fileName + "\n");
				writerItems.write(myProjectMap.get(project).get(fileName));
				writerItems.write("\n");
			}
			writerItems.write("///***///");
			writerItems.write("\n");
		}
		
		writerProject.close();
		writerItems.close();
		return true;
	}
	
//	public static void main(String[] args) throws IOException {
//		ProjectIO p = new ProjectIO();
//		p.myProjectMap.put("Project1", new TreeMap<String, String>());
//		p.myProjectMap.get("Project1").put("Item1", "path1");
//		p.myProjectMap.get("Project1").put("Item2", "path2");
//		
//		p.myProjectMap.put("Proj1", new TreeMap<String, String>());
//		
//		p.myProjectMap.put("Project2", new TreeMap<String, String>());
//		p.myProjectMap.get("Project2").put("Item21", "path21");
//		p.myProjectMap.get("Project2").put("Item22", "path22");
//		
//		p.saveData();
//		
//		p.load();
//		
//		p.saveData();
//	}
}