//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package model;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.HashSet;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JPanel;

import frontEnd.ProjectGUI;

/**
 * Class to load projects.  
 * 
 * called by GUI, loads project buttons.
 * 
 * @author Benjamin
 * 
 * @version 1.0.04
 */
public class Handler extends AbstractHandler {

	private static final long serialVersionUID = 1933113322812413087L;
	
	//Default project panel implementation.
	public Handler() throws IOException {
		super();
	}
	
	//this method is only here to avoid java complaining (we think its a bug). its parent class
	//already implements this.
	public void setUp() {
		//super.setUp();
	}

	//we do allow main gui to delete projects.
	@Override
	public boolean deleteProject(String theProject) {
		return super.deleteProject(theProject);
	}

	//we do allow main gui to create projects.
	@Override
	public boolean addProject(String theProject) {
		return super.addProject(theProject);
	}

	//we don't want main gui to delete items (yet at least).
	@Override
	public boolean deleteItem(String theItem) {
		return false;
	}
}
