/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package model;

import java.util.Map;

/**
 * 
 * @author Daniel Stocksett
 * @version 1.0.04
 *
 */

public interface HandlerInterface {	
	
	void setUp();
	
	boolean save();
	
	boolean deleteItem(String theItem);
	
	boolean addItem(String theItem, String theLocation);
	
	boolean  addProject(String theProject);

	boolean deleteItem(String theItem, String theName);

}
