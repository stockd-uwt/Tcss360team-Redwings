//Checked Out By: Benjamin

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package model;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import frontEnd.ProjectGUI;

/**
 * Abstract back-end control class. 
 * 
 * @author Benjamin
 * 
 * @version 1.0.04
 */
public abstract class AbstractHandler extends JScrollPane implements HandlerInterface {
	
	/**
	 * This is used to access the files and save things into them.
	 */
	protected final ProjectIO myFileManager = new ProjectIO();
	
	/**
	 * This is because we extend JScrollPane.
	 */
	private static final long serialVersionUID = -8807798734209999926L;

	/**
	 * PCS is needed for good OOP-based inter-package design.
	 */
	private final PropertyChangeSupport myPCS = new PropertyChangeSupport(this);
	
	/**
	 * Panel to add buttons to.
	 */
	private JPanel myButtonPanel;
	
	/**
	 * Needed to allow the PCS to communicate properly.
	 */
	private String theMessage;
	
	/**
	 * also needed for the PCS to communicate properly.
	 */
	private String myFixStr; //edit by: DS
	
	/**
	 * default button size.
	 */
	private static final Dimension BUTTON_SIZE = new Dimension(50,50);
	
	/**
	 * default length of left-most panel.
	 */
	private static final int LENGTH = 300;

	/**
	 * Default.
	 * @throws IOException 
	 */
	public AbstractHandler() throws IOException {
		//first tell projectIO to load the projects and items (if they exist).
		super();
		myFileManager.load();

		//then we run setup.
		setUp(myFileManager.getProjects());
		theMessage = "mainTEST";
		myFixStr = "";
	}
	
	/**
	 * Overloaded.
	 * 
	 * @param theSet called by ProjectGUI, loads project items.
	 * @throws IOException 
	 */
	public AbstractHandler(final String theProject) throws IOException {
		super();
		
		//we do much the same here as in above.
		try {
			myFileManager.load();
		} catch (IOException e) {
			System.out.println("could not load files!");
		}

		//but now we need to pass this set as well
		Set<String> theNames = (Set<String>) myFileManager.getMap(theProject).keySet();
		
		setUp(theNames, theProject);
		theMessage = "projectTest";
		myFixStr = theProject;
	}

	public void setUp(Set<String> theSet) {
		//we now need to create the panel.
		myButtonPanel = new JPanel();
		
		//then add the buttons, since we want the add on first, we do that first.
		myButtonPanel.add(createAddButton());
		for (String aElement: theSet) {
			
			//we then put a panel on this panel with both a open and delete button on it.
			//this is done by creating the open button and passing it to the
			//pairDeleteButton method.
			myButtonPanel.add(pairDeleteButton(createOpenButton(aElement)));
		}
			
		//we then finish off the panel with its needed settings.
		myButtonPanel.setPreferredSize(new Dimension(LENGTH, BUTTON_SIZE.height*4));
		myButtonPanel.setLayout(new GridLayout(0, 1));
		myButtonPanel.setVisible(true);

		//and add it to (this) which is a JSCrollpane.
		this.add(myButtonPanel);
		setViewportView(myButtonPanel);
		this.setVisible(true);
	}

	public void setUp(Set<String> theSet, String theProject) throws IOException { //edit by: DS
		
		//repeat as above, but pass in theproject name.
		myButtonPanel = new JPanel();
		myButtonPanel.add(createAddButton(theProject));

		for (String aElement: theSet) {
			//again, create a open and delete button for element.
			myButtonPanel.add(pairDeleteButton(createOpenButton(aElement, theProject), theProject));
		}
		
		//set the panels settings.
		myButtonPanel.setPreferredSize(new Dimension(LENGTH, BUTTON_SIZE.height*4));
		myButtonPanel.setLayout(new GridLayout(0, 1));
		myButtonPanel.setVisible(true);

		//and add/make visable
		this.add(myButtonPanel);
		setViewportView(myButtonPanel);
		this.setVisible(true);
	}

	//allow for external requests for file-saving.
	@Override
	public boolean save() {
		return myFileManager.saveData();
	}

	//allow for external requests for file deleting.
	@Override
	public boolean deleteItem(String theProject, String theItem) {
		return myFileManager.deleteItem(theProject, theItem);
	}

	//allow for external requests for project deleting.
	public boolean deleteProject(String theProject) {
		myFileManager.deleteProject(theProject);
		//we made this return a boolean to possably represent failure/success
		//to client code in the future.
		return true;
	}

	//allow for external requests for item adding.
	public boolean addItem(String projectName, String theLoc) {
		myFileManager.setNewItem(projectName, theLoc.substring(theLoc.lastIndexOf("/")), theLoc);
		//we made this return a boolean to possably represent failure/success
		//to client code in the future.
		return true;
	}

	//allow external requests to add projects.
	@Override
	public boolean addProject(String theProject) {
		myFileManager.setNewProject(theProject);
		return true;
	}
	
	//private helper method to allow the creation of buttons for mainHandler.
	private JButton createAddButton() {
		//create the button.
		final JButton myButton = new JButton("Create new Project");
		//add listener.
		myButton.addActionListener((ActionListener) new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				//get the new project name.
				addProject(getProjectName());
				//re setup the window.
				setUp(myFileManager.getProjects());
				myFileManager.saveData();
			}
			
		});
		//set the variables needed and return.
		myButton.setSize(BUTTON_SIZE);
		myButton.setVisible(true);
		return myButton;
	}
	
	private JButton createAddButton(final String theProject) {
		
		//repeat as above but for projecthandler behavior
		//(so basiclly its passed a project name to work with).
		final JButton myButton = new JButton("Create new Item");
		
		myButton.addActionListener((ActionListener) new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				//we need to encapsulate the documents into a item.
				Item newItem = createNewItem(theProject);
				setNewItem(newItem.projectOwner, newItem.itemName, newItem.documentLoc);
				
				Set<String> theItems = (Set<String>) myFileManager.getMap(theProject).keySet();
				//get the items from projectIO and run (setup) again to refresh.
				try {
					setUp(theItems, theProject);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				//save changes.
				myFileManager.saveData();
			}
			
		});
		 
		//set variables and return.
		myButton.setSize(new Dimension(60,40));
		myButton.setVisible(true);
		return myButton;
	}
	
	//this is similar to the "add" button but it merely opens a new projectGUI.
	private JButton createOpenButton(String theName) {  //edit by: DS
		//new button.
		final JButton myButton = new JButton(theName);
		//add listener.
		myButton.addActionListener((ActionListener) new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				//tell listeners that we need to open a project (the listener is a mainGUI).
				ext(theName);	
			}
			
		});
		
		//set variables and return.
		myButton.setSize(new Dimension(60,40));
		myButton.setVisible(true);
		return myButton;
	}
	
	//this is used by the "open" buttons to tell mainGUI that we did a thing.
	public void ext(String theName) {
		myFixStr = theName;
		firePropertyChange(theName, theMessage, theName);
		theMessage = theName;
	}
	
	//This is overloaded version of the other one...but it works with projectGUI to
	//open items instead.
	private JButton createOpenButton(String theName, String theProject) { //edit by: DS
		//new button.
		final JButton myButton = new JButton(theName);
		//add listener.
		myButton.addActionListener((ActionListener) new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent a) {
				myFixStr = myFileManager.getMap(theProject).get(theName);
			
				firePropertyChange(myFixStr, theMessage, myFixStr);
				theMessage = myFixStr;

			}
			
		});
		
		//set variables and return.
		myButton.setSize(new Dimension(BUTTON_SIZE));
		myButton.setVisible(true);
		return myButton;
	}
	
	//allow for external access to current state. (used by main/project GUI to listen.
	//might be changed/removed in future.
    @Override
	public String toString() {
		return myFixStr;
	}

    //we want to allow local access the ablity to set new items.
	protected boolean setNewItem(String project, String theItem, String theLocation) {
		return myFileManager.setNewItem(project, theItem, theLocation);
	}
	
	/**
	 * This is a helper method for getting user input via a JOptionPane.
	 * @return a String holding the user's choice of projectName
	 * @author Benjamin J De Jager
	 */
	private String getProjectName() {
		//create new frame to display a box for getting user input.
		JFrame frame = new JFrame();
	    String name = JOptionPane.showInputDialog(
	        frame, 
	        "Enter the new Project Name", 
	        "Creating: new Project", 
	        JOptionPane.QUESTION_MESSAGE
		);
		
	    //return what the user gives.
		return name;
	}
	
	/**
	 * This method is used pair a project JButton to a delete button that removes the project.
	 * @author Benjamin De Jager
	 * @param JButton
	 * @return JPanel this is the panel that the buttons are placed on, the delete button is on the right.
	 */
	private JPanel pairDeleteButton(JButton theButton) {
		//create a panel.
		JPanel thePanel = new JPanel();
		thePanel.setLayout(new GridLayout(1,2));
		
		//create a button and add a listener.
		JButton deleteTheThing = new JButton("Delete: " + theButton.getText());
		deleteTheThing.addActionListener((ActionListener) new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent a) {
				//we want to delete the project assosated with this button.
				deleteProject(theButton.getText());
				setUp(myFileManager.getProjects());
				//save and refresh.
				myFileManager.saveData();

			}
			
		});
		
		//set variables, add buttons to panel and return.
		deleteTheThing.setSize(BUTTON_SIZE);
		deleteTheThing.setVisible(true);
		thePanel.add(theButton);
		thePanel.add(deleteTheThing);
		
		return thePanel;
	}
	
	/**
	 * This method is used pair a item JButton to a delete button that removes the item.
	 * overloaded to allow similar behavior with items.
	 * (must be passed in a project name that holds said item).
	 * @author Benjamin De Jager
	 * @param JButton
	 * @return JPanel this is the panel that the buttons are placed on, the delete button is on the right.
	 * @throws IOException 
	 */
	private JPanel pairDeleteButton(JButton theButton, String theProject) throws IOException {
		//create panel
		JPanel thePanel = new JPanel();
		thePanel.setLayout(new GridLayout(1,2));
		
		//create button and listener.
		JButton deleteTheThing = new JButton("Delete: " + theButton.getText());
		deleteTheThing.addActionListener((ActionListener) new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent a) {
				//we need to delete the item assostated with the button.
				deleteItem(theProject, theButton.getText());
				//save a
				try {
					setUp(myFileManager.getMap(myFixStr).keySet(), myFixStr);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//save changes.
				myFileManager.saveData();
			}
			
		});
		
		//set variables, add components and return. 
		deleteTheThing.setSize(BUTTON_SIZE);
		deleteTheThing.setVisible(true);
		thePanel.add(theButton);
		thePanel.add(deleteTheThing);
		return thePanel;
	}
	
	/**
	 * This method creates a item within the specified project.
	 * @author Benjamin De Jager
	 * @param owningProject
	 * @return Item
	 */
	private Item createNewItem(final String owningProject) {
		//We first assume owningProject exists.

		//we need to allow the user to see a name-field and a file-chooser.
		JTextField itemName = new JTextField();
		JFileChooser fileFinder = new JFileChooser("Finding new item File Path");

		//display info.
		Object[] message = {
		    "New Item Name:", itemName,
		    "New Item File Path:", fileFinder
		};

		//open the dialog.
		JOptionPane.showInputDialog(null, message, "Create New Item", JOptionPane.OK_CANCEL_OPTION);
		
		int returnValue = fileFinder.showOpenDialog(null);
		// pull the users input for the name.
		File selectedFile;

		//check if they canseled.
		if (returnValue == JFileChooser.APPROVE_OPTION) {
			selectedFile = fileFinder.getSelectedFile();
		} else {
			return null;
		}
		
		//if not, then add new item.
		try {
			return new Item(owningProject, itemName.getText(), selectedFile.getAbsolutePath());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * This inner class is used for storing/encapsulating documents and their required behavior.
	 * @author Benjamin
	 * @version 1.0.04
	 */
	private class Item {

		/**
		 * This holds the item's owning project. 
		 */
		private final String projectOwner;
		
		/**
		 * This holds the documents location.
		 */
		private final String documentLoc;
		
		/**
		 * This holds the item's displayed name.
		 */
		private final String itemName;
		
		/**
		 * creates a new item holding a document and its project owner.
		 */
		private Item(final String ownerProject, final String newItemName, final String itemLoc) throws FileNotFoundException {
			//check the projectname.
			if (!myFileManager.getProjects().contains(ownerProject))
				throw new IllegalArgumentException("Error 01: ProjectPro tried to make a item in a invalid project.");
			projectOwner = ownerProject;
			
			//check the item name.
			if (myFileManager.getMap(ownerProject).containsKey(newItemName))
					throw new IllegalArgumentException("Error 02: ProjectPro tried to make a duplicate item name.");
			itemName = newItemName;
			
			//check the item path.
			File testFile = new File(itemLoc);
			if (!testFile.canRead())
				throw new IllegalArgumentException("Error 03: ProjectPro tried to make a item with a unreadable file path.");
			documentLoc = itemLoc;
		}
		
		//following methods are not currently used, but are for later usage.
		
		//this is used to access the internal item name.
		private String getName() {
			return itemName;
		}
		
		//this is used to access the internal path.
		private String getLoc() {
			return documentLoc;
		}
		
		//this is used to access the internal project name.
		private String getProjectFromItem() {
			return projectOwner;
		}
	}

}
