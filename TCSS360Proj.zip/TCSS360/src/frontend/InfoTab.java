package frontend;

public class InfoTab {
	private final String BEN    = "Ben DeJager";
	private final String DAVID  = "David Melanson";
	private final String DANIEL = "Daniel Stocksett";
	private final String VERSION= "0.0.01";

	public InfoTab() {

	}
	
	public String getVersion() {
		return VERSION;
	}

	public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append("BY:\n\r");
		sb.append("------------------------------------"
				+ "--------------------------|\n\r");

		sb.append("| Dev-side point of contact |");
		sb.append(DAVID + "\n\r");
		sb.append("|/software engineer            |");
		sb.append("\n\r|------------------------------------|"
				+ "------------------------|\n\r");

		sb.append("| Forms administration      |");
		sb.append(BEN + "\n\r");
		sb.append("|/ software engineer          |");
		sb.append("\n\r|-----------------------------------|"
				+ "------------------------|\n\r");

		sb.append("| System architect             |");
		sb.append(DANIEL + "\n\r");
		sb.append("| / software engineer         |");
		sb.append("\n\r|-----------------------------------|"
				+ "------------------------|\n\r");

		sb.append("| Version =                           |" + VERSION);
		sb.append("\n\r-----------------------------------|"
				+ "------------------------|\n\r");

		return sb.toString();
	}
}

/**
 * This code goes in the button listener.
 * --need to inport JOption to GUI class
 */
