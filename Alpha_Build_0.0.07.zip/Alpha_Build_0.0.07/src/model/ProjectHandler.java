//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package model;

import java.util.Map;

import javax.swing.JPanel;

/**
 * Class to load and provide project items. 
 * 
 * called by ProjectGUI, loads project item buttons.
 * 
 * @author Fill in your name!
 * 
 * @version Alpha 0.0.05
 */
public class ProjectHandler extends AbstractHandler {
	/* panel attachments may require a call to super(not sure), as the abstract extends JScrollPane.
	 * e.g.: super().addActionListener()
	 * Abstract parent should be filled out first!!!
	 */
	private static final long serialVersionUID = 3498482854205170500L;
	/**
	 * Panel to add buttons to.
	 */
	private JPanel myButtonPanel;

	//needs to load the items for a given project as buttons.
	public ProjectHandler(String theProject) {
		
	}
	//Self explanatory names.
	@Override
	public void setup() {
		// TODO Auto-generated method stub
		super.setup();
	}

	//Calls projectIO getMap().
	@Override
	public void loadButtons() {
		// TODO Auto-generated method stub
		super.loadButtons();
	}

	//Please pass a copy, not the original...
	//Only used if we do not implement Observer...
	@Override
	public Map<?, ?> getMap(String theProject) {
		// TODO Auto-generated method stub
		return null;
	}

	//Calls made to ProjectIO for functionality(next 3).

	@Override
	public boolean save() {
		// TODO Auto-generated method stub
		return super.save();
	}

	@Override
	public boolean deleteItem(String theItem) {
		// TODO Auto-generated method stub
		return super.deleteItem(theItem);
	}

	@Override
	public boolean addItem(String theItem) {
		// TODO Auto-generated method stub
		return super.addItem(theItem);
	}



}
