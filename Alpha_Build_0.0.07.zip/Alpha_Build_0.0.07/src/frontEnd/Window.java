//Checked Out By: David

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package frontEnd;

import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

/**
 * Sizable scalable display window. 
 * 
 * @author David Melanson
 * 
 * @version Alpha 0.0.06
 */
public class Window extends JPanel {
	/*
	 * Needs setup for generic display.
	 */
	public Window(Object theDoc, Dimension theSize, Dimension theScale) {
		
		// Not sure what to do with theDoc and theScale ~ David
        setPreferredSize(new Dimension(theSize));
        setVisible(true);
		
	}
	
	private void setUp() {
		//Put new Listener here where "null" is. --anonymous inner class.
		addMouseListener(new MouseAdapter() {

            @Override
            public void mousePressed(MouseEvent e) {
            	// do something when mouse is pressed
            }
        });
	}

}
