//Checked Out By: Benjamin

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package model;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import frontEnd.ProjectGUI;

/**
 * Abstract back-end control class. 
 * 
 * @author Benjamin
 * 
 * @version Alpha 0.0.08
 */
public abstract class AbstractHandler extends JScrollPane implements HandlerInterface {
	
	protected final ProjectIO myFileManager = new ProjectIO();
	/*
	 *Please fill out before child classes!!
	 *Calls are made to ProjectIO.
	 */
	private static final long serialVersionUID = -8807798734209999926L;

	/**
	 * PCS
	 */
	private final PropertyChangeSupport myPCS = new PropertyChangeSupport(this);
	
	/**
	 * Panel to add buttons to.
	 */
	private JPanel myButtonPanel;
	
	private String theMessage;
	
	private String myFixStr; //edit by: DS
	
	private static final Dimension BUTTON_SIZE = new Dimension(50,50);

	/**
	 * Default.
	 * @throws IOException 
	 */
	public AbstractHandler() throws IOException {
		//we want to pull up a map<Strings, map<Strings>> to 
		//represent a map of project names to each of their 
		//map's of Item names to said item's doc file location.
		super();
		myFileManager.load();
//		try {
//			myFileManager.load();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			System.out.println("Could not load files correctly!");
//		}
		setUp(myFileManager.getProjects());
		theMessage = "mainTEST";
		myFixStr = "";
	}
	
	/**
	 * Overloaded
	 * 
	 * @param theSet called by ProjectGUI, loads project items.
	 */
	public AbstractHandler(final String theProject) {
		super();
		try {
			myFileManager.load();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("could not load files!");
		}

		Set<String> theNames = (Set<String>) myFileManager.getMap(theProject).keySet();
		
		setUp(theNames, theProject);
		theMessage = "projectTest";
		myFixStr = "";
	}

	public void setUp(Set<String> theSet) {
		myButtonPanel = new JPanel();
		
		myButtonPanel.add(createAddButton());
		for (String aElement: theSet) {
			//System.out.println(aElement);
			myButtonPanel.add(pairDeleteButton(createOpenButton(aElement)));
		}
		//System.out.println(myButtonPanel);
		
		myButtonPanel.setPreferredSize(new Dimension(80, BUTTON_SIZE.height*4));
		myButtonPanel.setLayout(new GridLayout(0, 1));
		myButtonPanel.setVisible(true);

		this.add(myButtonPanel);
		setViewportView(myButtonPanel);
		this.setVisible(true);
	}

	public void setUp(Set<String> theSet, String theProject) { //edit by: DS
		myButtonPanel = new JPanel();

		myButtonPanel.add(createAddButton(theProject));
		for (String aElement: theSet) {
			//System.out.println(aElement);
			myButtonPanel.add(pairDeleteButton(createOpenButton(aElement, theProject), theProject));
		}
		//System.out.println(myButtonPanel);
		
		myButtonPanel.setPreferredSize(new Dimension(80, BUTTON_SIZE.height*4));
		myButtonPanel.setLayout(new GridLayout(0, 1));
		myButtonPanel.setVisible(true);


		this.add(myButtonPanel);
		setViewportView(myButtonPanel);
		this.setVisible(true);
	}

	public void loadButtons() {
		// TODO Auto-generated method stub
		
	}
//
//	@Override
//	public Map<?, ?> getMap(String theProject) {
//		return (Map<?, ?>) myProjects.get(theProject);
//	}

	@Override
	public boolean save() {
		return myFileManager.saveData();
	}

	@Override
	public boolean deleteItem(String theProject, String theItem) {
		return myFileManager.deleteItem(theProject, theItem);
	}

	public boolean deleteProject(String theProject) {
		myFileManager.deleteProject(theProject);
		return true;
	}


	public boolean addItem(String projectName, String theLoc) {
		// TODO Auto-generated method stub
		myFileManager.setNewItem(projectName, theLoc.substring(theLoc.lastIndexOf("/")), theLoc);
		return true;
	}

	@Override
	public boolean addProject(String theProject) {
		// TODO Auto-generated method stub
		myFileManager.setNewProject(theProject);
		return true;
	}
	
	private JButton createAddButton() {
		final JButton myButton = new JButton("Create new Project");
		myButton.addActionListener((ActionListener) new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				//get the new project name.
				addProject(getProjectName());
				//re setup the window.
				setUp(myFileManager.getProjects());
				myFileManager.saveData();
			}
			
		});
		myButton.setSize(BUTTON_SIZE);
		myButton.setVisible(true);
		return myButton;
	}
	
	private JButton createAddButton(final String theProject) {
		final JButton myButton = new JButton("Create new Item");
		myButton.addActionListener((ActionListener) new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				//System.out.println("I DID:"+theProject);
				Item newItem = createNewItem(theProject);
				setNewItem(newItem.projectOwner, newItem.itemName, newItem.documentLoc);
				Set<String> theItems = (Set<String>) myFileManager.getMap(theProject).keySet();
				setUp(theItems, theProject);
				myFileManager.saveData();
			}
			
		});
		myButton.setSize(new Dimension(60,40));
		myButton.setVisible(true);
		return myButton;
	}
	
	private JButton createOpenButton(String theName) {  //edit by: DS
		final JButton myButton = new JButton(theName);
		myButton.addActionListener((ActionListener) new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				//System.out.println("I DID:"+theName);
			ext(theName);	
			}
			
		});
		myButton.setSize(new Dimension(60,40));
		myButton.setVisible(true);
		return myButton;
	}
	public void ext(String theName) {
		myFixStr = theName;
		firePropertyChange(theName, theMessage, theName);
		theMessage = theName;


	}
	
	private JButton createOpenButton(String theName, String theProject) { //edit by: DS
		final JButton myButton = new JButton(theName);
		myButton.addActionListener((ActionListener) new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent a) {
				//System.out.println("I DID: "+myFileManager.getMap(theProject).get(theName));
				myFixStr = myFileManager.getMap(theProject).get(theName);
			
				firePropertyChange(myFixStr, theMessage, myFixStr);
				theMessage = myFixStr;

			}
			
		});
		myButton.setSize(new Dimension(BUTTON_SIZE));
		myButton.setVisible(true);
		return myButton;
	}
	

    @Override
	public String toString() {
		return myFixStr;
	}

	protected boolean setNewItem(String project, String theItem, String theLocation) {
		return myFileManager.setNewItem(project, theItem, theLocation);
	}
	
	/**
	 * This is a helper method for getting user input via a JOptionPane.
	 * @return a String holding the user's choice of projectName
	 * @author Benjamin J De Jager
	 */
	private String getProjectName() {
		//We want to see how large of a number is
		//required for default project names (project 1, vs project 256).
//		int largestNumber = 1;
//		while (myFileManager.getProjects().contains("Project " + largestNumber)) {
//			largestNumber++;
//		}
	
		JFrame frame = new JFrame();
	    String name = JOptionPane.showInputDialog(
	        frame, 
	        "Enter the new Project Name", 
	        "Creating: new Project", 
	        JOptionPane.QUESTION_MESSAGE
		);
		
		return name;
	}
	
	/**
	 * This method is used pair a project JButton to a delete button that removes the project.
	 * @author Benjamin De Jager
	 * @param JButton
	 * @return JPanel this is the panel that the buttons are placed on, the delete button is on the right.
	 */
	private JPanel pairDeleteButton(JButton theButton) {
		JPanel thePanel = new JPanel();
		thePanel.setLayout(new GridLayout(1,2));
		
		//System.out.println(theButton.getText());
		JButton deleteTheThing = new JButton("Delete: " + theButton.getText());
		deleteTheThing.addActionListener((ActionListener) new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent a) {
				//System.out.println("I DID: "+myFileManager.getMap(theProject).get(theName));
				deleteProject(theButton.getText());
				setUp(myFileManager.getProjects());
				myFileManager.saveData();
			}
			
		});
		deleteTheThing.setSize(BUTTON_SIZE);
		deleteTheThing.setVisible(true);
		thePanel.add(theButton);
		thePanel.add(deleteTheThing);
		return thePanel;
	}
	
	/**
	 * This method is used pair a item JButton to a delete button that removes the item.
	 * @author Benjamin De Jager
	 * @param JButton
	 * @return JPanel this is the panel that the buttons are placed on, the delete button is on the right.
	 */
	private JPanel pairDeleteButton(JButton theButton, String theProject) {
		JPanel thePanel = new JPanel();
		thePanel.setLayout(new GridLayout(1,2));
		
		//System.out.println(theButton.getText());
		JButton deleteTheThing = new JButton("Delete: " + theButton.getText());
		deleteTheThing.addActionListener((ActionListener) new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent a) {
				System.out.println("I DID: "+myFileManager.getMap(theProject).get(theButton.getText()));
				deleteItem(theProject, theButton.getText());
				try {
					myFileManager.load();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				setUp(myFileManager.getMap(myFixStr).keySet(), myFixStr);
				myFileManager.saveData();
			}
			
		});
		deleteTheThing.setSize(BUTTON_SIZE);
		deleteTheThing.setVisible(true);
		thePanel.add(theButton);
		thePanel.add(deleteTheThing);
		return thePanel;
	}
	
	/**
	 * This method creates a item within the specified project.
	 * @author Benjamin De Jager
	 * @param owningProject
	 * @return Item
	 */
	private Item createNewItem(final String owningProject) {
		//We first assume owningProject exists.

		JTextField itemName = new JTextField();
		JFileChooser fileFinder = new JFileChooser("Finding new item File Path");

		Object[] message = {
		    "New Item Name:", itemName,
		    "New Item File Path:", fileFinder
		};

		//JOptionPane.showInputDialog(null, message, "Create New Item", JOptionPane.OK_CANCEL_OPTION);
		
		int returnValue = fileFinder.showOpenDialog(null);
		// int returnValue = jfc.showSaveDialog(null);
		File selectedFile;

		if (returnValue == JFileChooser.APPROVE_OPTION) {
			selectedFile = fileFinder.getSelectedFile();
		} else {
			return null;
		}
		
		try {
			String thing = helMe(selectedFile.getAbsolutePath());
			//System.out.println(thing);
			return new Item(owningProject, thing, selectedFile.getAbsolutePath());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	private String helMe(String string) {
		String sb = string;
		while (sb.contains("\\")) {
			System.out.println(sb);
			sb = sb.substring(sb.indexOf('\\') + 1, sb.length());
			
		}
		return sb;
	}

	/**
	 * This inner class is used for storing documents and their required behavior.
	 * @author Benjamin
	 *
	 */
	private class Item {

		/**
		 * This holds the item's owning project. 
		 */
		private final String projectOwner;
		
		/**
		 * This holds the documents location.
		 */
		private final String documentLoc;
		
		/**
		 * This holds the item's displayed name.
		 */
		private final String itemName;
		
		/**
		 * creates a new item holding a document and its project owner.
		 */
		private Item(final String ownerProject, final String newItemName, final String itemLoc) throws FileNotFoundException {
			if (!myFileManager.getProjects().contains(ownerProject))
				throw new IllegalArgumentException("Error 01: ProjectPro tried to make a item in a invalid project.");
			projectOwner = ownerProject;
			
			if (myFileManager.getMap(ownerProject).containsKey(newItemName))
					throw new IllegalArgumentException("Error 02: ProjectPro tried to make a duplicate item name.");
			itemName = newItemName;
			
			File testFile = new File(itemLoc);
			if (!testFile.canRead())
				throw new IllegalArgumentException("Error 03: ProjectPro tried to make a item with a unreadable file path.");
			documentLoc = itemLoc;
		}
		
		private String getName() {
			return itemName;
		}
		
		private String getLoc() {
			return documentLoc;
		}
	}

}
