/*
 * This program was used for assignment 05 for CSS 305 winter 2019.
 * This file is owned by Benjamin De Jager
 */

package frontend;

import java.awt.EventQueue;

/**
 * This runs and controls all the things needed for the program to run.
 * @author benjad2
 * @version 0.1.
 */
public final class Driver {

    /**
     * private constructor to prevent external instantiation.
     * @return 
     */
    private void projectMain() {
        throw new IllegalStateException();
    }
    
    /**
     * This gets the program started.
     * @param theArgs these are not used.
     */
    public static void main(final String[] theArgs) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new GUI().start();
            }
        });
    }


}

