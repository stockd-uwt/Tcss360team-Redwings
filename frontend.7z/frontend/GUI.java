/**
 * 
 */
package frontend;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;

import javax.swing.AbstractAction;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

/**
 * @author benjad2
 *
 */
class GUI {
    
    /** This program's title. */
    private static final String TITLE = "360-collab-project";    
    
    /** toolkit for ensuring that the frame takes up 1/3 of the screen. */
    private static final Toolkit SCREEN_KIT = Toolkit.getDefaultToolkit();
    
    /** default width of the JPanel. */
    private static final int DEFAULT_WIDTH = (int) SCREEN_KIT.getScreenSize().getWidth() / 3;

    /** default height of the JPanel. */
    private static final int DEFAULT_HEIGHT = (int) SCREEN_KIT.getScreenSize().getHeight() / 3;
    
    /** location that GUI is placed on the x-axis. */
    private static final int DEFAULT_X = (int) SCREEN_KIT.getScreenSize().getWidth() / 3;
    
    /** location that GUI is placed on the y-axis. */
    private static final int DEFAULT_Y = (int) SCREEN_KIT.getScreenSize().getHeight() / 3;
    
    /** This is a JMenu for holding the options as defined as JMenuItems. */
    private JMenuBar myMenu;
    
    /** This is the top-level Jframe. */
    private final JFrame myFrame;

    /**
     * 
     */
    GUI() {
	super();
	myFrame = new JFrame();
    }

    public void start() {

        //get the Tool out of our first Action.
        
        createToolBar();
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFrame.setJMenuBar(myMenu);
        
        myFrame.setSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
        myFrame.setLocation(DEFAULT_X, DEFAULT_Y);
        myFrame.setVisible(true);
    }

    private void createToolBar() {
	final JMenuBar menuBar = new JMenuBar();
        
        final JMenu optionMenu = new JMenu("Options");
        
        final JMenuItem viewOption = new JMenuItem("View-Options...");
        final JMenuItem sortOption = new JMenuItem("Sort-Options...");
        final JMenuItem aboutOption = new JMenuItem("About");
        
        aboutOption.addActionListener(new aboutListener());
        
        optionMenu.add(viewOption);
        optionMenu.add(sortOption);
        optionMenu.add(aboutOption);
        
        menuBar.add(optionMenu);     

        myMenu = menuBar;
    }

    private final class aboutListener extends AbstractAction {

	private aboutListener() {
	    super();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
	    System.out.println("This is a test-string");
	}
    }


}
