//Checked Out By: Benjamin

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package model;

import java.util.Map;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 * Abstract back-end control class. 
 * 
 * @author Fill in your name!
 * 
 * @version Alpha 0.0.05
 */
public abstract class AbstractHandler extends JScrollPane implements HandlerInterface {

	/*
	 *Please fill out before child classes!!
	 *Calls are made to ProjectIO.
	 */
	private static final long serialVersionUID = -8807798734209999926L;


	/**
	 * Default.
	 */
	public AbstractHandler() {
		
	}
	/**
	 * Overloaded
	 * 
	 * @param theProject called by ProjectGUI, loads project items.
	 */
	public AbstractHandler(String theProject) {
		
	}

	public void setup() {
		// TODO Auto-generated method stub
		
	}

	public void loadButtons() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Map getMap(String theProject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean save() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteItem(String theItem) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteProject(String theProject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addItem(String theItem) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addProject(String theProject) {
		// TODO Auto-generated method stub
		return false;
	}
	


}
