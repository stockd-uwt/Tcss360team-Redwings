//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package frontEnd;

/**
 * Class for settings, may wish to move menu bar here... 
 * 
 * @author Fill in your name!
 * 
 * @version Alpha 0.0.05
 */
public class Settings {

}
