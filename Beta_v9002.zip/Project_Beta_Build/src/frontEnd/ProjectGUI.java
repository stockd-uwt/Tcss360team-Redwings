//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package frontEnd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

import model.Handler;
import model.ProjectHandler;

/**
 * Project item GUI class. 
 * 
 * @author Daniel Stocksett
 * 
 * @version Alpha 0.0.05
 */
public class ProjectGUI extends AbstractGUI {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2796607903023915076L;
	/*
	 * Things needed to build GUI...
	 */
	//private JPanel myLeftPanel;
	private ProjectHandler myCenterPanel;
	private JPanel myRightPanel;
	
	/*
	 * Add override panels to build functionality--just mirroring its parent class now.
	 */
	public ProjectGUI(String theProject) throws IOException {
		super();
		setTitle("Project: " + theProject);
		// myLeftPanel = new JPanel();
		 myCenterPanel = new ProjectHandler(theProject);
		 myRightPanel= new JPanel();
		 //myRightPanel = new Window(); //uncomment and replace after window coded.
	}

	@Override
	public void createToolBar() {
		super.createToolBar();
	}

	@Override
	public void start() {
		super.start();
		
		setLayout(new BorderLayout());
		
		myRightPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH/2, DEFAULT_HEIGHT));
		myRightPanel.setBackground(Color.WHITE);
		myRightPanel.setVisible(true);
		
		add(myRightPanel, BorderLayout.EAST);
		
		//temp test code next 2 lines
		//myCenterPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH/2, DEFAULT_HEIGHT));
		//myCenterPanel.setBackground(Color.RED);
		
		//end test code
		myCenterPanel.getViewport().setOpaque(false);
		myCenterPanel.setVisible(true);
		myCenterPanel.addPropertyChangeListener(new GUIListener());
		add(myCenterPanel, BorderLayout.CENTER);
		
		pack();
	}
	private void setPane() {
		 JPanel dummy = new JPanel();
		 dummy.setPreferredSize(new Dimension(DEFAULT_WIDTH/2, DEFAULT_HEIGHT));
		 dummy.setBackground(Color.WHITE);
		// dummy.setVisible(true);
		 dummy.add(myRightPanel);
		 add(dummy, BorderLayout.EAST);
		 pack();
		
		//add(myRightPanel, BorderLayout.EAST);
		//myRightPanel.setVisible(true);
		//setVisible(true);
		//pack();
	}
	private final class GUIListener implements PropertyChangeListener  {

		@Override
		public void propertyChange(PropertyChangeEvent evt) {
			Window win;
		


		if (evt.getPropertyName().equals(myCenterPanel.toString()))	{
			try {
				 win = new Window(evt.getPropertyName(), new Dimension(DEFAULT_WIDTH/2, DEFAULT_HEIGHT));
				
				 myRightPanel = win;
				 setPane();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		}
		
	}
//	@Override
//	public void windowOpened(WindowEvent e) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void windowClosing(WindowEvent e) {
//		myCenterPanel.save();
//		
//	}
//
//	@Override
//	public void windowClosed(WindowEvent e) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void windowIconified(WindowEvent e) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void windowDeiconified(WindowEvent e) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void windowActivated(WindowEvent e) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void windowDeactivated(WindowEvent e) {
//		// TODO Auto-generated method stub
//		
//	}


}
