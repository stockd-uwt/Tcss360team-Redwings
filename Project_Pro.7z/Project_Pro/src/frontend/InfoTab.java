/**
 * Author: Daniel Stockett.
 * Purpose: to allow the other classes to get information that is
 * required to be displayed to the user in the about-screen.
 */
package frontend;

/**
 * See above.
 */
public class InfoTab {
	/**
	 * These three strings are used to display the authors of this program.
	 */
	private final String BEN    = "Ben DeJager";
	private final String DAVID  = "David Melanson";
	private final String DANIEL = "Daniel Stocksett";
	/**
	 * This string is used to store the programs current version number.
	 */
	private String VERSION = "0.0.02";

	/**
	 * This is a default constructor with no parameters for this class.
	 */
	public InfoTab() {

	}
	
	/**
	 * This method allows other classes to query the version number of this project.
	 * @return a String in the format of: 'x.yy.zz' such that x,y and z correspond to different integers.
	 * It has no pre-conditons.
	 **/
	public String getVersion() {
	    return VERSION;
	}
	
	/**
	 * This method allows other classes to set the version number of this project.
	 * It does no input-checking for now, (this is version 0.0.1 afterall).
	 * @param newVersion This should be a string in the form of: 'x.yy.zz'.
	 * pre: newVersion must be a string in a valid format.
	 * post: the infotab's version string is set to newVersion.
	 */
	public void setVersion(String newVersion) {
	    VERSION = newVersion;
	    //System.out.println("set Version number: " + newVersion + " | it is now: "+ VERSION);
	}

	/**
	 * This allows for easy access for the about screen to display info to the user.
	 * pre: none.
	 * post: returns a user-readable string displaying project information.
	 */
	public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append("BY:\n\r");
		sb.append("------------------------------------"
				+ "--------------------------|\n\r");

		sb.append("| Dev-side point of contact |");
		sb.append(DAVID + "\n\r");
		sb.append("|/ software engineer            |");
		sb.append("\n\r|------------------------------------|"
				+ "------------------------|\n\r");

		sb.append("| Forms administration      |");
		sb.append(BEN + "\n\r");
		sb.append("|/ software engineer          |");
		sb.append("\n\r|-----------------------------------|"
				+ "------------------------|\n\r");

		sb.append("| System architect             |");
		sb.append(DANIEL + "\n\r");
		sb.append("|/ software engineer         |");
		sb.append("\n\r|-----------------------------------|"
				+ "------------------------|\n\r");

		sb.append("| Version =                           |" + VERSION);
		sb.append("\n\r-----------------------------------|"
				+ "------------------------|\n\r");

		return sb.toString();
	}
}

/*
 * This code goes in the button listener.
 * --need to import JOption to GUI class
 */
