/**
 * This class was made to be the main GUI for the final version of our project.
 * right now it is 99% non-functional as only the about-screen is accessable.
 * Author: Benjamin De Jager.
 */
package frontend;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//import java.beans.PropertyChangeListener;
import javax.swing.JOptionPane;

import javax.swing.AbstractAction;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

/**
 * @author benjad2
 * @version 0.0.2
 */
public class GUI {

	/** This program's title. */
	private static final String TITLE = "360-collab-project";    

	/** toolkit for ensuring that the frame takes up 1/3 of the screen. */
	private static final Toolkit SCREEN_KIT = Toolkit.getDefaultToolkit();

	/** default width of the JPanel. */
	private static final int DEFAULT_WIDTH = (int) SCREEN_KIT.getScreenSize().getWidth() / 3;

	/** default height of the JPanel. */
	private static final int DEFAULT_HEIGHT = (int) SCREEN_KIT.getScreenSize().getHeight() / 3;

	/** location that GUI is placed on the x-axis. */
	private static final int DEFAULT_X = (int) SCREEN_KIT.getScreenSize().getWidth() / 3;

	/** location that GUI is placed on the y-axis. */
	private static final int DEFAULT_Y = (int) SCREEN_KIT.getScreenSize().getHeight() / 3;

	/** This is a JMenu for holding the options as defined as JMenuItems. */
	private JMenuBar myMenu;

	/** This is the top-level Jframe. */
	private final JFrame myFrame;
	
	/** for holding onto the users name */
	private String name;
	
	/** for holding onto the user's email */
	private String email;


	private String versionNum;

	/**
	 * This is a constructor to allow main to create the GUI.
	 * pre: none.
	 * post: a new GUI is created.
	 */
	public GUI() {
		super();
		myFrame = new JFrame();
	}

	/**
	 * This method allows the driver to run this class.
	 * pre: none.
	 * post: the GUI is displayed to the user.
	 */
	public void start() {

		//get the Tool out of our first Action.

		createToolBar();
		myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myFrame.setJMenuBar(myMenu);

		myFrame.setSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		myFrame.setLocation(DEFAULT_X, DEFAULT_Y);
		myFrame.setVisible(true);
	}

	/**
	 * This method is used locally by the .start method to create the toolbar.
	 * pre: none.
	 * post: the Toolbar is created and added to myFrame.
	 */
	private void createToolBar() {
		final JMenuBar menuBar = new JMenuBar();

		final JMenu optionMenu = new JMenu("Options");
		final JMenu settingOption = new JMenu("Settings");
		
		final JMenuItem viewOption = new JMenuItem("View-Options...");
		final JMenuItem sortOption = new JMenuItem("Sort-Options...");
		final JMenuItem aboutOption = new JMenuItem("About");
		
		aboutOption.addActionListener(new aboutListener());
		
		final JMenuItem userNameSetting = new JMenuItem("UserName");
		final JMenuItem emailSetting = new JMenuItem("Email");
		final JMenuItem importSetting = new JMenuItem("Import settings");
		final JMenuItem exportSetting = new JMenuItem("Export settings");
		
		userNameSetting.addActionListener(new UserNameListener());
		emailSetting.addActionListener(new EmailListener());
		importSetting.addActionListener(new ImportListener());
		exportSetting.addActionListener(new ExportListener());

		optionMenu.add(viewOption);
		optionMenu.add(sortOption);
		optionMenu.add(aboutOption);
		
		settingOption.add(userNameSetting);
		settingOption.add(emailSetting);
		settingOption.add(importSetting);
		settingOption.add(exportSetting);

		menuBar.add(optionMenu);     
		menuBar.add(settingOption);

		myMenu = menuBar;
	}

	/** 
	 * This Class is used locally to allow the options menubar to function
	 * as a button.
	 * @author Benjamin De Jager
	 */
	private final class aboutListener extends AbstractAction {

		/**
		 * This is a standard constructor for this class.
		 */
		private aboutListener() {
			super();
		}
		
		/**
		 * This is a method that allows for various classes (in this case the GUI)
		 * to call methods when a button is pressed.
		 * pre: a actionevent e is passed in (a button is pressed).
		 * post: a optionpane is opened with no options (so a info page really).
		 */
		@Override
		public void actionPerformed(ActionEvent e) {
			InfoTab tab = new InfoTab();
			JOptionPane.showMessageDialog(null, tab);
			//System.out.println("This is a test-string");
		}
	}
	
	private final class UserNameListener extends AbstractAction {

		private UserNameListener() {
			super();
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			JOptionPane optionPane = new JOptionPane();
			JDialog dialog = optionPane.createDialog(new JFrame(),"Change Username");
			String n = optionPane.showInputDialog("Enter new username: ");
			if (n != null)
				name = n;
		}
	}	
	
	private final class EmailListener extends AbstractAction {

		private EmailListener() {
			super();
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			JOptionPane optionPane = new JOptionPane();
			JDialog dialog = optionPane.createDialog(new JFrame(),"Change Email");
			String n = optionPane.showInputDialog("Enter new email: ");
			if (n != null)
				email = n;
		}
	}	
	
	private final class ImportListener extends AbstractAction {

		private ImportListener() {
			super();
		}
		@Override
		public void actionPerformed(ActionEvent e) {
		}
	}	

	private final class ExportListener extends AbstractAction {

		private ExportListener() {
			super();
		}
		@Override
		public void actionPerformed(ActionEvent e) {
		}
	}	
}
