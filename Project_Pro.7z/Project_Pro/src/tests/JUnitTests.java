/**
 * This file was created by David. 
 * Its purpose is to test the functionality of the setter and getter methods provided 
 * in the frontend package to get and set the version number of this project.
 */
package tests;

import static org.junit.Assert.*;
import frontend.InfoTab;

import org.junit.Before;
import org.junit.Test;

/**
 * 
 * Tests the GUI
 * See above.
 */
public class JUnitTests {
    
	/**
	 * This is a instance of a InfoTab to test its functionality, This makes this a 
	 * white-box testing.
	 */
    private InfoTab myTab;
    
    /**
     * A method to initialize the test feature before each test.
     * Purpose, to setup for the two rounds of testing required.
     * Pre: Infotab is a valid, instantable class.
     * Post: a Infotab is created.
     */
    @Before
    public void setUp() { 
        myTab = new InfoTab();
    }
    
    /**
     * Test of the default constructor.
     * Purpose: that the default Infotab class returns the correct version.
     */
    @Test
    public void testPassableVersionNum() {
    	assertEquals(myTab.getVersion(), "0.0.01");
    }
    
    /**
     * Purpose: that the Infotab class allows for setting of the version number.
     */
    @Test
    public void testChangeVersionNum() {
	myTab.setVersion("0.0.02");
    	assertEquals(myTab.getVersion(), "0.0.02");
        
    }
}














