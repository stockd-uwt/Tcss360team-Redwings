/**
 * 
 */
package testproject;

/**
 * @author Ben
 *
 */
public final class helloworld {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Hello World!\n");
		System.out.print("team redwings!");
	}

}
