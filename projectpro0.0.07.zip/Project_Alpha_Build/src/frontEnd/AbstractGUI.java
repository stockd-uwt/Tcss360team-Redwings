//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
/**
 * Components of this class were adapted from the original Project_Pro
 */
package frontEnd;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.io.IOException;

import javax.swing.AbstractAction;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import frontEnd.InfoTab;
import frontEnd.SettingsIO;

/**
 * Abstract front-end control class. 
 * 
 * @author Written by Ben, Adapted for project by Daniel.
 * 
 * @version Alpha 0.0.05
 */
public abstract class AbstractGUI extends JFrame implements InterfaceGUI  { /**
	 * 
	 */
	private static final long serialVersionUID = 1744217516316914640L;

//Edited by: DS 11/23/19 

	/** This program's title. */
	protected static final String TITLE = "360-collab-project";    

	/** toolkit for ensuring that the frame takes up 1/3 of the screen. */
	private static final Toolkit SCREEN_KIT = Toolkit.getDefaultToolkit();

	/** default width of the JPanel. */
	protected static final int DEFAULT_WIDTH = (int) SCREEN_KIT.getScreenSize().getWidth() / 2;

	/** default height of the JPanel. */
	protected static final int DEFAULT_HEIGHT = (int) SCREEN_KIT.getScreenSize().getHeight() / 2;

	/** location that GUI is placed on the x-axis. */
	private static final int DEFAULT_X = (int) SCREEN_KIT.getScreenSize().getWidth() / 2;

	/** location that GUI is placed on the y-axis. */
	private static final int DEFAULT_Y = (int) SCREEN_KIT.getScreenSize().getHeight() / 2;

	/** This is a JMenu for holding the options as defined as JMenuItems. */
	private JMenuBar myMenu;

	/** This is the top-level Jframe. */
	//private final JFrame myFrame;
	
	/** for holding onto the users name */
	private String name;
	
	/** for holding onto the user's email */
	private String email;


	private String versionNum;
	/**
	 * This is a constructor to allow main to create the GUI.
	 * pre: none.
	 * post: a new GUI is created.
	 */
	public AbstractGUI() {
		super();
		//myFrame = new JFrame();
	}
	public AbstractGUI(String theProject) {
		super();
		//myFrame = new JFrame();
	}

	@Override
	public void createToolBar() {
		final JMenuBar menuBar = new JMenuBar();

		final JMenu optionMenu = new JMenu("Options");
		final JMenu settingOption = new JMenu("Settings");
		
		final JMenuItem inportOp = new JMenuItem("Inport settings");
		final JMenuItem exportOp = new JMenuItem("Export settings");
		
		final JMenuItem viewOption = new JMenuItem("View-Options...");
		final JMenuItem sortOption = new JMenuItem("Sort-Options...");
		final JMenuItem aboutOption = new JMenuItem("About");
		
		final JMenuItem userNameSetting = new JMenuItem("UserName");
		final JMenuItem emailSetting = new JMenuItem("Email");
		
		aboutOption.addActionListener(new aboutListener());
		userNameSetting.addActionListener(new UserNameListener());
		emailSetting.addActionListener(new EmailListener());
		inportOp.addActionListener(new InputListener());
		exportOp.addActionListener(new OutputListener());

		optionMenu.add(viewOption);
		optionMenu.add(sortOption);
		optionMenu.add(aboutOption);
		
		settingOption.add(userNameSetting);
		settingOption.add(emailSetting);
		settingOption.add(inportOp);
		settingOption.add(exportOp);

		

		menuBar.add(optionMenu);     
		menuBar.add(settingOption);

		myMenu = menuBar;		
	}

	@Override
	public void start() {

		//get the Tool out of our first Action.

		createToolBar();
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setJMenuBar(myMenu);

		setSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		setLocation(DEFAULT_X, DEFAULT_Y);
		setVisible(true);		
	}
	/** 
	 * This Class is used locally to allow the options menubar to function
	 * as a button.
	 * @author Benjamin De Jager
	 */
	private final class aboutListener extends AbstractAction {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * This is a standard constructor for this class.
		 */
		private aboutListener() {
			super();
		}
		
		/**
		 * This is a method that allows for various classes (in this case the GUI)
		 * to call methods when a button is pressed.
		 * pre: a actionevent e is passed in (a button is pressed).
		 * post: a optionpane is opened with no options (so a info page really).
		 */
		@Override
		public void actionPerformed(ActionEvent e) {
			InfoTab tab = new InfoTab();
			JOptionPane.showMessageDialog(null, tab);
			//System.out.println("This is a test-string");
		}
	}
	
	private final class UserNameListener extends AbstractAction {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		private UserNameListener() {
			super();
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			JOptionPane optionPane = new JOptionPane();
			JDialog dialog = optionPane.createDialog(new JFrame(),"Change Username");
			String n = JOptionPane.showInputDialog("Enter new username: ");
			if (n != null)
				name = n;
		}
	}	
	
	private final class EmailListener extends AbstractAction {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private EmailListener() {
			super();
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			JOptionPane optionPane = new JOptionPane();
			JDialog dialog = optionPane.createDialog(new JFrame(),"Change Email");
			String n = optionPane.showInputDialog("Enter new email: ");
			if (n != null)
				email = n;
		}
	}	

private final class InputListener extends AbstractAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void actionPerformed(ActionEvent e) {
SettingsIO test = new SettingsIO();		
try {
	test.inport();
} catch (IOException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}
	}
	
}
private final class OutputListener extends AbstractAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void actionPerformed(ActionEvent e) {
		SettingsIO test = new SettingsIO();		
		try {
			test.export();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}		
	}
	
}

}
