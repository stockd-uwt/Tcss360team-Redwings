//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package model;

import javax.swing.JPanel;

/**
 * Class to load projects.  
 * 
 * called by GUI, loads project buttons.
 * 
 * @author Fill in your name!
 * 
 * @version Alpha 0.0.05
 */
public class Handler extends AbstractHandler {
	/* panel attachments may require a call to super(not sure), as the abstract extends JScrollPane.
	 * e.g.: super().addActionListener()
	 * Abstract parent should be filled out first!!!
	 */
	private static final long serialVersionUID = 1933113322812413087L;
	/**
	 * Panel to add buttons to.
	 */
	private JPanel myButtonPanel;
	
	//Default project panel implementation.
	public Handler() {
		
	}

	//Self explanatory names
	@Override
	public void setup() {
		// TODO Auto-generated method stub
		super.setup();
	}

	//Calls ProjectIO getProjects().
	@Override
	public void loadButtons() {
		// TODO Auto-generated method stub
		super.loadButtons();
	}

	//Calls made to ProjectIO for functionality(next 3).
	@Override
	public boolean save() {
		// TODO Auto-generated method stub
		return super.save();
	}

	@Override
	public boolean deleteProject(String theProject) {
		// TODO Auto-generated method stub
		return super.deleteProject(theProject);
	}

	@Override
	public boolean addProject(String theProject) {
		// TODO Auto-generated method stub
		return super.addProject(theProject);
	}



}
