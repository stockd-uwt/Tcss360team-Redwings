//Checked Out By: n/a

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package model;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Class to handle project and project item IO. 
 * 
 * @author Fill in your name!
 * 
 * @version Alpha 0.0.05
 */
public class ProjectIO {
	
	/*
	 * Class uses EITHER a list if "node" objects OR a map of type <Project-name, Map<File-name, File-address>>,
	 * So long as getMap returns the map for the correct project either works, 
	 * map of maps is more efficient once loaded.
	 */
	private static final String PROJECT_FILE = "projects.txt";
	private static final String Project_Item_File = "items.txt";
	
	//uncomment for list of nodes implementation.
	//private List<Node> myData;
	
	private Map<String, Map<String, String>> myProjectMap;
	
	protected ProjectIO() {
		//myData = new LinkedList<Node>();
	}
	//load projects from file.
	private void loadProjects() {
		
	}
	//load items belonging to projects to their project map.
	private void loadProjectItems() {
		
	}
	//returns the keySet or list of projects (implementation dependent
	//- Change return type to list for node implementation)
	protected Set<String> getProjects() {
		return myProjectMap.keySet();
		
	}
	//Please pas a copy, not the original map...
	protected Map getMap(String theProject) {
		return null;
		
	}
	//Self explanatory names
	protected void setNewItem(String theItem, String theLocation) {
		
	}
	protected void setNewProject(String theProject) {
		
	}
	protected void deleteItem(String theItem) {
		
	}
	protected void deleteProject(String theProject) {
		
	}
	protected void saveData() {
		
	}

	//Uncomment for node implementation.
	/*
	 * protected class Node { private String myProject; private Map<String, String>
	 * myProjectItems;
	 * 
	 * Node(String theProject) {
	 * 
	 * } private void loadProjectItems() {
	 * 
	 * } protected String getProject() { return null;
	 * 
	 * } protected Map getMap() { return null;
	 * 
	 * } protected void deleteItem(String theItem) {
	 * 
	 * } protected void setItem() {
	 * 
	 * }
	 * 
	 * }
	 */
}
