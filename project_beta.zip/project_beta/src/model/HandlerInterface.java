/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package model;

import java.util.Map;

public interface HandlerInterface {	
	void loadButtons();
	
	void setUp();
	
	//Map getMap(String theProject);
	
	boolean save();
	
	boolean deleteItem(String theItem);
	
	boolean addItem(String theItem);
	
	boolean  addProject(String theProject);

	boolean deleteItem(String theItem, String theName);

}
