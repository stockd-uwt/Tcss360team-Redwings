//Checked Out By: Benjamin

/* Team RedWings (David, Daniel, and Ben)
 * 
 * Tcss 360
 * 
 * Project 1
 */
package model;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import frontEnd.ProjectGUI;

/**
 * Abstract back-end control class. 
 * 
 * @author Benjamin
 * 
 * @version Alpha 0.0.08
 */
public abstract class AbstractHandler extends JScrollPane implements HandlerInterface {
	
	protected final ProjectIO myFileManager = new ProjectIO();
	/*
	 *Please fill out before child classes!!
	 *Calls are made to ProjectIO.
	 */
	private static final long serialVersionUID = -8807798734209999926L;

	/**
	 * PCS
	 */
	private final PropertyChangeSupport myPCS = new PropertyChangeSupport(this);
	
	/**
	 * Panel to add buttons to.
	 */
	private JPanel myButtonPanel;
	
	private String theMessage;
	
	private String myFixStr; //edit by: DS
	
	private static final Dimension BUTTON_SIZE = new Dimension(50,50);

	/**
	 * Default.
	 * @throws IOException 
	 */
	public AbstractHandler() throws IOException {
		//we want to pull up a map<Strings, map<Strings>> to 
		//represent a map of project names to each of their 
		//map's of Item names to said item's doc file location.
		super();
		myFileManager.load();
//		try {
//			myFileManager.load();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			System.out.println("Could not load files correctly!");
//		}
		setUp(myFileManager.getProjects());
		theMessage = "mainTEST";
		myFixStr = "";
	}
	
	/**
	 * Overloaded
	 * 
	 * @param theSet called by ProjectGUI, loads project items.
	 */
	public AbstractHandler(final String theProject) {
		super();
		try {
			myFileManager.load();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("could not load files!");
		}

		Set<String> theNames = (Set<String>) myFileManager.getMap(theProject).keySet();
		
		setUp(theNames, theProject);
		theMessage = "projectTest";
	}

	public void setUp(Set<String> theSet) {
		myButtonPanel = new JPanel();
		
		for (String aElement: theSet) {
			//System.out.println(aElement);
			myButtonPanel.add(createButton(aElement));
		}
		//System.out.println(myButtonPanel);
		
		myButtonPanel.setPreferredSize(new Dimension(80, 50*2));
		myButtonPanel.setLayout(new GridLayout(theSet.size(), 1));
		myButtonPanel.setVisible(true);

		this.add(myButtonPanel);
		setViewportView(myButtonPanel);
		this.setVisible(true);
	}
	
	public void setUp(Set<String> theSet, String theProject) { //edit by: DS
		myButtonPanel = new JPanel();
		
		for (String aElement: theSet) {
			//System.out.println(aElement);
			myButtonPanel.add(createButton(aElement, theProject));
		}
		//System.out.println(myButtonPanel);
		
		myButtonPanel.setPreferredSize(new Dimension(80, 50*2));
		myButtonPanel.setLayout(new GridLayout(theSet.size(), 1));
		myButtonPanel.setVisible(true);

		this.add(myButtonPanel);
		setViewportView(myButtonPanel);
		this.setVisible(true);
	}

	public void loadButtons() {
		// TODO Auto-generated method stub
		
	}
//
//	@Override
//	public Map<?, ?> getMap(String theProject) {
//		return (Map<?, ?>) myProjects.get(theProject);
//	}

	@Override
	public boolean save() {
		return myFileManager.saveData();
	}

	@Override
	public boolean deleteItem(String theProject, String theItem) {
		return myFileManager.deleteItem(theProject, theItem);
	}

	public boolean deleteProject(String theProject) {
		return false;
	}

	@Override
	public boolean addItem(String theItem) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addProject(String theProject) {
		// TODO Auto-generated method stub
		return false;
	}
	
	private JButton createButton(String theName) {  //edit by: DS
		final JButton myButton = new JButton(theName);
		myButton.addActionListener((ActionListener) new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				//System.out.println("I DID:"+theName);
			ext(theName);	
			}
			
		});
		myButton.setSize(new Dimension(60,40));
		myButton.setVisible(true);
		return myButton;
	}
	public void ext(String theName) {
		myFixStr = theName;
		firePropertyChange(theName, theMessage, theName);
		theMessage = theName;


	}
	
	private JButton createButton(String theName, String theProject) { //edit by: DS
		final JButton myButton = new JButton(theName);
		myButton.addActionListener((ActionListener) new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent a) {
				//System.out.println("I DID: "+myFileManager.getMap(theProject).get(theName));
				myFixStr = myFileManager.getMap(theProject).get(theName);
			
				firePropertyChange(myFixStr, theMessage, myFixStr);
				theMessage = myFixStr;

			}
			
		});
		myButton.setSize(new Dimension(60,40));
		myButton.setVisible(true);
		return myButton;
	}
	

    @Override
	public String toString() {
		return myFixStr;
	}

	protected boolean setNewItem(String theName, String theItem, String substring) {
		return myFileManager.setNewItem(theName, theItem, substring);
	}
}
